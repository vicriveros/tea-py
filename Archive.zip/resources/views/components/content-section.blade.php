
<div class="rounded-sm border border-stroke bg-white px-5 pb-2.5 pt-6 shadow-default sm:px-7.5 xl:pb-1" >
    <h4 class="mb-6 text-xl font-bold text-black">
        {{ $title }}
    </h4>

    {{ $slot }}

</div>
