<td {!! $attributes->merge(['class' => 'border-t-0 px-6 align-middle border-l-0 border-r-0 text-sm whitespace-nowrap p-4']) !!}>
    {{ $slot }}
</td>