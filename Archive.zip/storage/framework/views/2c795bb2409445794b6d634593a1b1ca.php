<button 
    <?php echo e($attributes->merge(['class' => 'flex justify-center rounded bg-primary p-3 font-medium text-gray hover:bg-opacity-90 place-self-end'])); ?>

>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/vdriveros/Herd/tea-py/resources/views/components/button.blade.php ENDPATH**/ ?>