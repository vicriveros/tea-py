<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'sortable' => false, 
    'column' => null, 
    'sortCol' => null, 
    'sortAsc' => null
    ]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'sortable' => false, 
    'column' => null, 
    'sortCol' => null, 
    'sortAsc' => null
    ]); ?>
<?php foreach (array_filter(([
    'sortable' => false, 
    'column' => null, 
    'sortCol' => null, 
    'sortAsc' => null
    ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<th <?php echo $attributes->merge(['class' => 'px-6 bg-blueGray-50 text-blueGray-500 align-middle border border-solid border-blueGray-100 py-3 text-base uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left']); ?> >
    <!--[if BLOCK]><![endif]--><?php if($sortable): ?>
        <button wire:click="sortBy('<?php echo e($column); ?>')" class="flex items-center gap-2">
            <?php echo e($slot); ?>


                <!--[if BLOCK]><![endif]--><?php if($sortCol === $column): ?>
                    <div class="text-gray-400">
                        <!--[if BLOCK]><![endif]--><?php if($sortAsc): ?>
                            <i class="fa-solid fa-sort-up"></i>
                        <?php else: ?>
                            <i class="fa-solid fa-sort-down"></i>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php else: ?>
                    <div class="text-gray-400 ">
                        <i class="fa-solid fa-sort"></i>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </button> 
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</th><?php /**PATH /Users/vdriveros/Herd/tea-py/resources/views/components/th.blade.php ENDPATH**/ ?>